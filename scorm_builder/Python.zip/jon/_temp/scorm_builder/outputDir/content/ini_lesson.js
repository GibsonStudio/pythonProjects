var lesson_title = 'Practical AC Generators'
var my_scenes;
my_scenes = [];
my_scenes.push(['index.html', 'Introduction.']);
my_scenes.push(['AC-alt-gen-s2.html', 'Brushed AC Generator.']);
my_scenes.push(['AC-alt-gen-s3.html', 'Brushless AC Generator.']);
my_scenes.push(['AC-alt-gen-s4.html', 'Permanent Magnet Generator (PMG).']);
my_scenes.push(['AC-alt-gen-s5.html', 'Frequency Wild AC Generator.']);
my_scenes.push(['AC-alt-gen-s6.html', 'Variable Speed Constant Frequency System (VSCF).']);
my_scenes.push(['AC-alt-gen-s7.html', 'Constant Speed Drive Unit (CSDU or CSD).']);
my_scenes.push(['AC-alt-gen-s8.html', 'CSDU Faults.']);
my_scenes.push(['AC-alt-gen-s9.html', 'CSDU Disconnect.']);
my_scenes.push(['AC-alt-gen-s10.html', 'Generator Cooling.']);
my_scenes.push(['AC-alt-gen-s11.html', 'Summary.']);
